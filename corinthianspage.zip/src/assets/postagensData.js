import foto1 from '../assets/imagens/foto1.png';
import foto2 from '../assets/imagens/foto2.png';
import foto3 from '../assets/imagens/foto3.png';
import foto4 from '../assets/imagens/foto4.png';
import foto5 from '../assets/imagens/foto5.png';
import foto6 from '../assets/imagens/foto6.png';
import foto7 from '../assets/imagens/foto7.png';
import foto8 from '../assets/imagens/foto8.jpeg';
import foto9 from '../assets/imagens/foto9.jpeg';
import foto10 from '../assets/imagens/foto10.jpeg';
import foto11 from '../assets/imagens/foto11.jpeg';
import foto12 from '../assets/imagens/foto12.jpeg';
import foto13 from '../assets/imagens/foto13.jpeg';
import foto14 from '../assets/imagens/foto14.jpeg';
import foto15 from '../assets/imagens/foto15.jpeg';
import foto16 from '../assets/imagens/foto16.jpeg';
import foto17 from '../assets/imagens/foto17.jpeg';
import foto18 from '../assets/imagens/foto18.jpeg';
import foto19 from '../assets/imagens/foto19.jpeg';

const postagensData =[
  {
    image: foto1,
  },
  {
    image: foto2,
  },
  {
    image: foto3,
  },
  {
    image: foto4,
  },
  {
    image: foto5,
  },
  {
    image: foto6,
  },
  {
    image: foto7,
  },
  {
    image: foto8,
  },
  {
    image: foto9,
  },
  {
    image: foto10,
  },
  {
    image: foto11,
  },
  {
    image: foto12,
  },
  {
    image: foto13,
  },
  {
    image: foto14,
  },
  {
    image: foto15,
  },
  {
    image: foto16,
  },
  ,
  {
    image: foto17,
  }
]


export default postagensData;